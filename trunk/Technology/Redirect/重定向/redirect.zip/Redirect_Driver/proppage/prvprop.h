#ifndef __PRVPROP_H__
#define __PRVPROP_H__

//ClassGuid={0c833dae-8679-11d3-b19b-0060b0efd4aa}

#define STATIC_REDIRECTID_PRIVATE \
    0x0c833dae, 0x8679, 0x11d3, 0xb1, 0x9b, 0x00, 0x60, 0xb0, 0xef, 0xd4, 0xaa
struct __declspec(uuid("0c833dae-8679-11d3-b19b-0060b0efd4aa")) REDIRECTID_PRIVATE;
#define REDIRECTID_PRIVATE __uuidof(struct REDIRECTID_PRIVATE)

const int PROPERTY_REDIRECT_FEATURES = 1;

// Structure passed in the private property request with method
// PROPERTY_REDIRECT_FEATURES.


#endif __PRVPROP_H__