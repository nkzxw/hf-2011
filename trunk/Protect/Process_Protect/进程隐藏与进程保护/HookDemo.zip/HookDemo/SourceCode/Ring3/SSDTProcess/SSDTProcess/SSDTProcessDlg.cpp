
// SSDTProcessDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SSDTProcess.h"
#include "SSDTProcessDlg.h"
#include "AboutDialog.h"
#include "afxdialogex.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CSSDTProcessDlg::CSSDTProcessDlg(CWnd* pParent /*=NULL*/) : CDialogEx(CSSDTProcessDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	this->m_hDevice = NULL;
}


void CSSDTProcessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_PROCESS, m_ListCtrlProcess);
}


BEGIN_MESSAGE_MAP(CSSDTProcessDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDCANCEL, &CSSDTProcessDlg::OnBnClickedCancel)
	ON_BN_CLICKED(ID_BTN_HIDEORUNHIDE, &CSSDTProcessDlg::OnBnClickedBtnHideorunhide)
	ON_BN_CLICKED(ID_BTN_PROTECTORUNPROTECT, &CSSDTProcessDlg::OnBnClickedBtnProtectorunprotect)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_PROCESS, &CSSDTProcessDlg::OnItemChangedListProcess)
	ON_BN_CLICKED(ID_BTN_ABOUT, &CSSDTProcessDlg::OnBnClickedBtnAbout)
END_MESSAGE_MAP()


//MFC Ӧ�ó���Ի����ʼ����Ϣ��������
BOOL CSSDTProcessDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon=AfxGetApp()->LoadIcon(IDI_ICON1);

	//���ô˶Ի����ͼ�꣬��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�ִ�д˲���
	SetIcon(hIcon, TRUE);
	SetIcon(hIcon, FALSE);

	::SetWindowLong(m_hWnd, GWL_EXSTYLE, GetWindowLong(m_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);  
	::SetLayeredWindowAttributes(m_hWnd, 0, 215, LWA_ALPHA);

	wstring wStrSysPath = GetSysFilePath();
	BOOL bResult = InstallSvc(((LPTSTR)(LPCTSTR)SSDT01_SERVICE_NAME), ((LPTSTR)(LPCTSTR)SSDT01_SERVICE_NAME), ((LPTSTR)(LPCTSTR)wStrSysPath.c_str()), SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START);
	if(FALSE == bResult)
	{
		MessageBox(_TEXT(" Install SSDT Service Failed , Application Auto Exit !  "), _TEXT("Application Error"), MB_OK | MB_ICONSTOP);
		CDialogEx::OnCancel();		
		return FALSE;
	}
	else
	{
		bResult = StartSvc(SSDT01_SERVICE_NAME);
		if(FALSE == bResult)
		{
			MessageBox(_TEXT(" Start SSDT Service Failed , Application Auto Exit !  "), _TEXT("Application Error"), MB_OK | MB_ICONSTOP);
			CDialogEx::OnCancel();
			return FALSE;
		}
	}

	this->m_hDevice = CreateFile(SSDT01_DEVICE_NAME, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(INVALID_HANDLE_VALUE == this->m_hDevice)
	{
		MessageBox(_TEXT(" Open SSDT Device Failed , Application Auto Exit !  "), _TEXT("Application Error"), MB_OK | MB_ICONSTOP);

		CDialogEx::OnCancel();
		return FALSE;
	}

	//��ʼ�� ListCtrl �ؼ�
	InitListCtrl();

	//����ǰ���еĽ�����Ϣȫ����䵽 vector ��
	FillPIDVector();

	//��ʼ�� ListCtrl Ĭ��ѡ��� 0 ��
	m_currSeletedIndex = 0;

	//�� vector �е����ݵ� ListCtrl ��
	BindVectorProcessToListCtrl();

	//�趨��ʱ��
	SetTimer(SSDT_PROCESS_TIMER_ID, SSDT_PROCESS_TIMER_INTERVAL, NULL);

	return TRUE;
}


//�����Ի���������С����ť������Ҫ����Ĵ��������Ƹ�ͼ��
//����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó����⽫�ɿ���Զ���ɡ�
void CSSDTProcessDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}


//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ
HCURSOR CSSDTProcessDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


//��ʼ�� ListCtrl �ؼ�
void CSSDTProcessDlg::InitListCtrl()
{
	this->m_ListCtrlProcess.SetExtendedStyle(m_ListCtrlProcess.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP | LVS_EX_TWOCLICKACTIVATE);

	this->m_ListCtrlProcess.InsertColumn(0, _TEXT(""), LVCFMT_CENTER, 25);
	this->m_ListCtrlProcess.InsertColumn(1, _TEXT("PID"), LVCFMT_LEFT, 45);
	this->m_ListCtrlProcess.InsertColumn(2, _TEXT("Name"), LVCFMT_LEFT, 115);
	this->m_ListCtrlProcess.InsertColumn(3, _TEXT("Path"), LVCFMT_LEFT, 285);
	this->m_ListCtrlProcess.InsertColumn(4, _TEXT("State"), LVCFMT_CENTER, 85);
}


//��ѯ�� SSDT01.SYS ���ڵ�·��
wstring CSSDTProcessDlg::GetSysFilePath()
{
	LPWSTR lpszDrct;
	lpszDrct = (LPWSTR)malloc(sizeof(LPWSTR) * MAX_PATH);
	GetCurrentDirectory(MAX_PATH, lpszDrct);

	wstring wStrDrct = lpszDrct;
	wstring wStrName = SSDT01_SYS_FILE_PATH;
	wstring wStrSysPath = wStrDrct + wStrName;

	return wStrSysPath;
}


//������ǰ���еĽ��̣����ҽ����� ID ��䵽���� vectorPID ��
void CSSDTProcessDlg::FillPIDVector()
{
	DWORD dwPIDArray[MAX_PROCESS_COUNT];
	DWORD dwNeededBytes;
	DWORD dwProcCount;

	dwNeededBytes = 0;
	dwProcCount = 0;
	memset(dwPIDArray, 0, sizeof(DWORD) * MAX_PROCESS_COUNT);
	if(NULL != EnumProcesses(dwPIDArray, sizeof(dwPIDArray), &dwNeededBytes))
	{
		dwProcCount = dwNeededBytes / sizeof(DWORD);
	}

	BubbleSort(dwPIDArray, dwProcCount);

	ClearVector();
	for(int i=0; i<dwProcCount; i++)
	{
		PROCESS_BIND procBind;
		procBind.dwPID = dwPIDArray[i];
		if(dwPIDArray[i] == 0)
		{
			procBind.state = ProcessStateUnknown;
		}
		else
		{
			procBind.state = ProcessStateGeneral;
		}
		this->m_vctAllProcess.push_back(procBind);
	}
}


//��֤�����Ƿ���Ч�����ý����Ƿ񱻽����ˣ��������˷��� FALSE��δ���������� TRUE
BOOL CSSDTProcessDlg::ValidateProcess(DWORD dwPID)
{
	HANDLE hProcess;

	if(dwPID == 0 || dwPID == 4)
	{
		return TRUE;
	}

	hProcess = NULL;
	hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, dwPID);
	if(hProcess != NULL)
	{
		CloseHandle(hProcess);
		return TRUE;
	}
	return FALSE;
}


//�������
void CSSDTProcessDlg::ClearVector()
{
	this->m_vctAllProcess.clear();
}


//�ж�һ�������Ƿ�����ڽ����б���
BOOL CSSDTProcessDlg::IsExistInVectorAllProcess(DWORD dwPID)
{
	for(int i=0;i<this->m_vctAllProcess.size();i++)
	{
		if(this->m_vctAllProcess.at(i).dwPID == dwPID)
		{
			return TRUE;
		}
	}
	return FALSE;
}


//���� ListCtrl �е�������ж� dwPID �� ListCtrl ���Ƿ��Ѿ�������
int CSSDTProcessDlg::IsExistInListCtrl(DWORD dwPID)
{
	int nCount = this->m_ListCtrlProcess.GetItemCount();
	for(int i=0; i<nCount;i++)
	{
		CString cStrPID = this->m_ListCtrlProcess.GetItemText(i, 1);
		int nPID = _tstoi(cStrPID.GetBuffer());
		if(dwPID == nPID)
		{
			return i;
		}
	}
	return -1;
}


//�� ListCtrl ��ָ������λ�� nIndex ������һ����¼
void CSSDTProcessDlg::InsertProcessToListCtrl(PROCESS_BIND procBind, int nIndex)
{
	int nItem;
	CString cStrPID;
	HANDLE hProcess;

	if(procBind.dwPID == 0 || procBind.dwPID == 4)
	{
		cStrPID.Format(_TEXT("%d"), procBind.dwPID);

		//ÿ�ζ����뵽 ListCtrl �ĵ� nIndex ������λ��
		nItem = this->m_ListCtrlProcess.InsertItem(nIndex, cStrPID);

		//���������ͼ��
		this->m_ListCtrlProcess.SetItemText(nItem, 0, _TEXT(""));
		this->m_ListCtrlProcess.SetItemText(nItem, 1, cStrPID);

		if(procBind.dwPID == 0)
		{
			this->m_ListCtrlProcess.SetItemText(nItem, 2, _TEXT("System Idle"));
		}
		else
		{
			this->m_ListCtrlProcess.SetItemText(nItem, 2, _TEXT("System"));
		}

		this->m_ListCtrlProcess.SetItemText(nItem, 3, _TEXT(""));
	}
	else
	{
		//����Ȩ�޵� SE_DEBUG 
		AdjustProcessTokenPrivilege();
		hProcess = NULL;
		hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, procBind.dwPID);
		if(NULL == hProcess)
		{
			if(procBind.dwPID != 0 && procBind.dwPID != 4)
			{
				OutputErrorMessage(_TEXT("InsertProcessToListCtrlBack - OpenProcess Failed , Error Code Is %d , Error Message Is %s !"));
			}

			return;
		}
		else
		{
			//��Ҫ���� dwPID ����ȡ�����̵� Icon��Name,Path

			TCHAR chDeviceName[MAX_PATH];
			TCHAR chPathName[MAX_PATH];
			DWORD dwLen = MAX_PATH;
			memset(chDeviceName, 0, sizeof(TCHAR) * MAX_PATH);
			memset(chPathName, 0, sizeof(TCHAR) * MAX_PATH);

			//��ý���ӳ���ļ����ڵ�·��������Ϊ��֧�� XP,Vista �Լ� 2000 �Ȳ���ϵͳ
			//ʹ�� API GetProcessImageFileName ������豸·��
			//Ȼ��ͨ��ת��������ļ�·������������ chPathName ��
			LoadVolumeAndDeviceName2Map();
			GetProcessImageFileName(hProcess, chDeviceName, MAX_PATH);
			DeviceName2PathName(chPathName, chDeviceName);

			mapDvc2Path.clear();
			CloseHandle(hProcess);

			PTCHAR pStrProcName;

			//ͨ��·������ý�������
			pStrProcName =  PathFindFileName(chPathName);
			cStrPID.Format(_TEXT("%d"), procBind.dwPID);

			//ÿ�ζ����뵽 ListCtrl �� nIndex ������λ��
			nItem = this->m_ListCtrlProcess.InsertItem(nIndex, chPathName);

			//���������ͼ��
			this->m_ListCtrlProcess.SetItemText(nItem, 0, _TEXT(""));
			this->m_ListCtrlProcess.SetItemText(nItem, 1, cStrPID);
			this->m_ListCtrlProcess.SetItemText(nItem, 2, pStrProcName);
			this->m_ListCtrlProcess.SetItemText(nItem, 3, chPathName);
		}
	}

	if(procBind.state == ProcessStateGeneral)
	{
		this->m_ListCtrlProcess.SetItemText(nItem, 4, _TEXT("General"));
	}
	else if(procBind.state == ProcessStateHide)
	{
		this->m_ListCtrlProcess.SetItemText(nItem, 4, _TEXT("Hide"));
	}
	else if(procBind.state == ProcessStateProtect)
	{
		this->m_ListCtrlProcess.SetItemText(nItem, 4, _TEXT("Protect"));
	}
	else if(procBind.state == ProcessStateHideAndProtect)
	{
		this->m_ListCtrlProcess.SetItemText(nItem, 4, _TEXT("HideAndProtect"));
	}
	else
	{
		this->m_ListCtrlProcess.SetItemText(nItem, 4, _TEXT("Unknown"));
	}
}


//�� ListCtrl �м������Ҫ����Ľ��̵�����λ��
int CSSDTProcessDlg::GetInsertIndexInListCtrl(DWORD dwPID)
{
	int nCount = this->m_ListCtrlProcess.GetItemCount();
	DWORD dwPrevPID = 0;
	for(int i=0; i<nCount;i++)
	{
		CString cStrPID = this->m_ListCtrlProcess.GetItemText(i, 1);
		int nPID = _tstoi(cStrPID.GetBuffer());
		
		if(dwPID >= dwPrevPID && dwPID < nPID)
		{
			return i;
		}
		dwPrevPID = nPID;
	}

	return dwPrevPID;
}


//ͨ������ PID ���� ListCtrl �в��ҵ�������λ��
int CSSDTProcessDlg::QueryItemIndexByPID(DWORD dwPID)
{
	int nCount = this->m_ListCtrlProcess.GetItemCount();
	for(int i=0; i<nCount;i++)
	{
		CString cStrPID = this->m_ListCtrlProcess.GetItemText(i, 1);
		int nPID = _tstoi(cStrPID.GetBuffer());

		if(dwPID == nPID)
		{
			return i;
		}
	}

	return -1;
}


//ʵ��ð�������㷨����������
void CSSDTProcessDlg::BubbleSort(PDWORD dwPIDArray, int len)
{
	int tmp;
	for(int i=0; i<len; i++)
	{
		for(int j=i+1; j<len; j++)
		{
			if(dwPIDArray[i] < dwPIDArray[j])
			{
				tmp = dwPIDArray[j];
				dwPIDArray[j] = dwPIDArray[i];
				dwPIDArray[i] = tmp;
			}
		}
	}
}


//ʵ�ֶ� vector �����е��������򣬽�������
void CSSDTProcessDlg::VectorProcessBubbleSort()
{
	PROCESS_BIND procBindTmp;
	int nProcCount = this->m_vctAllProcess.size();
	for(int i=0; i<nProcCount; i++)
	{
		for(int j=i+1; j<nProcCount; j++)
		{
			if(this->m_vctAllProcess.at(i).dwPID < this->m_vctAllProcess.at(j).dwPID)
			{
				procBindTmp = this->m_vctAllProcess.at(j);
				this->m_vctAllProcess.at(j) = this->m_vctAllProcess.at(i);
				this->m_vctAllProcess.at(i) = procBindTmp;
			}
		}
	}
}


//ʵ�ֽ� vector �����е����ݰ󶨵� ListCtrl ��
void CSSDTProcessDlg::BindVectorProcessToListCtrl()
{
	//���� vctAllProcess �������������Ѿ���Ч�Ľ���ɾ��
	for(int i=0;i<this->m_vctAllProcess.size();i++)
	{
		if(ValidateProcess(this->m_vctAllProcess.at(i).dwPID) == FALSE)
		{
			if(i < m_vctAllProcess.size() - 1)
			{
				this->m_vctAllProcess.at(i) = this->m_vctAllProcess.at(m_vctAllProcess.size() - 1);
			}
			this->m_vctAllProcess.pop_back();
		}
	}

	//�� VectorProcess �����е����ݽ�������
	VectorProcessBubbleSort();

	int nIndex = 0;
	for(int i=0; i<this->m_vctAllProcess.size(); i++)
	{
		nIndex = IsExistInListCtrl(this->m_vctAllProcess.at(i).dwPID);
		if(nIndex == -1)
		{
			int nTmpIndex = GetInsertIndexInListCtrl(this->m_vctAllProcess.at(i).dwPID);
			InsertProcessToListCtrl(this->m_vctAllProcess.at(i), nTmpIndex);
		}
	}

	//���� ListCtrl �е����еĽ��̣�������Ч�Ľ�����Ҫɾ��
	for(int i=0; i<this->m_ListCtrlProcess.GetItemCount(); i++)
	{
		CString cStrPID = this->m_ListCtrlProcess.GetItemText(i, 1);
		int nPID = _tstoi(cStrPID.GetBuffer());
		if(ValidateProcess(nPID) == FALSE)
		{
			this->m_ListCtrlProcess.DeleteItem(i);
		}
	}

	int nProcesses;
	CString cStrProcesses; 

	nProcesses = this->m_ListCtrlProcess.GetItemCount();
	cStrProcesses.Format(_TEXT("%d"), nProcesses);

	this->SetDlgItemText(IDC_STATIC_PROCESSES, cStrProcesses);

	//this->m_ListCtrlProcess.SetItemState(this->m_currSeletedIndex, LVIS_SELECTED, LVIS_SELECTED);
	//this->m_ListCtrlProcess.EnsureVisible(this->m_currSeletedIndex, TRUE);
}


//��ʱ����Ϣ��������
void CSSDTProcessDlg::OnTimer(UINT_PTR nIDEvent)
{
	//http://www.codeproject.com/KB/list/CColorListCtrl.aspx
	//http://www.codeproject.com/KB/list/Extended_List_Control.aspx
	//http://www.codeproject.com/KB/list/ReportControl.aspx
	//http://www.vckbase.com/document/viewdoc/?id=1480
	//http://blog.chinaunix.net/space.php?uid=790245&do=blog&cuid=1120889
	//http://blog.chinaunix.net/link.php?url=http://support.microsoft.com%2Fkb%2F141834%2Fen-us
	//http://blog.chinaunix.net/link.php?url=http://support.microsoft.com%2Fkb%2F141834%2Fen-us%23appliesto
	if(nIDEvent == SSDT_PROCESS_TIMER_ID)
	{
		DWORD dwPIDArray[MAX_PROCESS_COUNT];
		DWORD dwNeededBytes;
		DWORD dwProcCount;

		dwNeededBytes = 0;
		dwProcCount = 0;
		memset(dwPIDArray, 0, sizeof(DWORD) * MAX_PROCESS_COUNT);
		if(NULL != EnumProcesses(dwPIDArray, sizeof(dwPIDArray), &dwNeededBytes))
		{
			dwProcCount = dwNeededBytes / sizeof(DWORD);
		}

		//�����´����Ľ��̣�����Ҫ���ӵ� VctAllProcess ������
		for(int i=0;i<dwProcCount;i++)
		{
			if(IsExistInVectorAllProcess(dwPIDArray[i]) == FALSE)
			{
				PROCESS_BIND proBind;
				proBind.dwPID = dwPIDArray[i];
				proBind.state = ProcessStateGeneral;
				m_vctAllProcess.push_back(proBind);
			}
		}

		//���°�����
		BindVectorProcessToListCtrl();
	}
	CDialogEx::OnTimer(nIDEvent);
}


//=====================================================================================//
//Name: void VolumeName2DeviceName()                                                   //
//                                                                                     //
//Descripion: ��������ת��Ϊ�豸��				    							     	   //
//=====================================================================================//
void CSSDTProcessDlg::VolumeName2DeviceName(PWCHAR DeviceName, PWCHAR VolumeName)
{
	DWORD  CharCount = MAX_PATH + 1;
	PWCHAR Names     = NULL;
	PWCHAR NameIdx      = NULL;
	BOOL   Success      = FALSE;

	for (;;)
	{
		Names = (PWCHAR)new BYTE [CharCount * sizeof(WCHAR)];

		if (!Names)
		{
			return;
		}

		Success = GetVolumePathNamesForVolumeNameW(VolumeName, Names, CharCount, &CharCount);

		if (Success)
		{
			break;
		}

		if (GetLastError() != ERROR_MORE_DATA)
		{
			break;
		}

		delete [] Names;
		Names = NULL;
	}

	if (Success)
	{
		for (NameIdx = Names; NameIdx[0] != L'\0'; NameIdx += wcslen(NameIdx) + 1)
		{
			mapDvc2Path[DeviceName] = NameIdx;
		}
	}

	if (Names != NULL)
	{
		delete [] Names;
		Names = NULL;
	}

	return;
}


//=====================================================================================//
//Name: bool LoadVolumeAndDeviceName2Map()                                             //
//                                                                                     //
//Descripion: ���ص�ǰϵͳ�����еĴ����������Ӧ���豸���� Map						     	   //
//=====================================================================================//
bool CSSDTProcessDlg::LoadVolumeAndDeviceName2Map()
{
	bool   bRet               = FALSE; 
	DWORD  CharCount           = 0;
	WCHAR  DeviceName[MAX_PATH] = L"";
	DWORD  Error              = ERROR_SUCCESS;
	HANDLE FindHandle          = INVALID_HANDLE_VALUE;
	BOOL   Found              = FALSE;
	size_t Index              = 0;
	BOOL   Success                = FALSE;
	WCHAR  VolumeName[MAX_PATH] = L"";

	FindHandle = FindFirstVolumeW(VolumeName, ARRAYSIZE(VolumeName));

	if (FindHandle == INVALID_HANDLE_VALUE)
	{
		Error = GetLastError();
		wprintf(L"FindFirstVolumeW failed with error code %d\n", Error);
		return bRet;
	}

	for (;;)
	{
		Index = wcslen(VolumeName) - 1;

		if (VolumeName[0]     != L'\\' ||
			VolumeName[1]     != L'\\' ||
			VolumeName[2]     != L'?'  ||
			VolumeName[3]     != L'\\' ||
			VolumeName[Index] != L'\\')
		{
			Error = ERROR_BAD_PATHNAME;
			wprintf(L"FindFirstVolumeW/FindNextVolumeW returned a bad path: %s\n", VolumeName);
			break;
		}

		VolumeName[Index] = L'\0';

		CharCount = QueryDosDeviceW(&VolumeName[4], DeviceName, ARRAYSIZE(DeviceName));

		VolumeName[Index] = L'\\';

		if ( CharCount == 0 )
		{
			Error = GetLastError();
			wprintf(L"QueryDosDeviceW failed with error code %d\n", Error);
			break;
		}

		VolumeName2DeviceName(DeviceName, VolumeName);

		Success = FindNextVolumeW(FindHandle, VolumeName, ARRAYSIZE(VolumeName));

		if ( !Success )
		{
			Error = GetLastError();

			if (Error != ERROR_NO_MORE_FILES)
			{
				wprintf(L"FindNextVolumeW failed with error code %d\n", Error);
				break;
			}

			Error = ERROR_SUCCESS;
			break;
		}
	}

	FindVolumeClose(FindHandle);
	FindHandle = INVALID_HANDLE_VALUE;

	return bRet;
}


//=====================================================================================//
//Name: void DeviceName2PathName()                                                     //
//                                                                                     //
//Descripion: ���豸����ת��Ϊ·��          	    							     	   //
//=====================================================================================//
void CSSDTProcessDlg::DeviceName2PathName(WCHAR* szPathName, const WCHAR* szDeviceName)
{
	memset(szPathName, 0, MAX_PATH * 2);

	wstring strDeviceName = szDeviceName;
	size_t pos = strDeviceName.find(L'\\', 9);
	wstring strTemp1 = strDeviceName.substr(0, pos);
	wstring strTemp2 = strDeviceName.substr(pos + 1);
	wstring strDriverLetter  = mapDvc2Path[strTemp1];
	wstring strPathName = strDriverLetter + strTemp2;

	wcscpy_s(szPathName, MAX_PATH, strPathName.c_str());
}


//=====================================================================================//
//Name: bool AdjustProcessTokenPrivilege()                                             //
//                                                                                     //
//Descripion: ������ǰ����Ȩ��										  		               //
//=====================================================================================//
BOOL CSSDTProcessDlg::AdjustProcessTokenPrivilege()
{
	LUID luidTmp;
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;

	if(!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
	{
		OutputErrorMessage(_TEXT("AdjustProcessTokenPrivilege - OpenProcessToken Failed , Error Code Is {0} , Error Message Is {1} ! \n"));

		return false;
	}

	if(!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &luidTmp))
	{
		OutputErrorMessage(_TEXT("AdjustProcessTokenPrivilege - LookupPrivilegeValue Failed , Error Code Is {0} , Error Message Is {1} ! \n"));

		CloseHandle(hToken);

		return FALSE;
	}

	tkp.PrivilegeCount = 1;
	tkp.Privileges[0].Luid = luidTmp;
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	if(!AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), NULL, NULL))
	{
		OutputErrorMessage(_TEXT("AdjustProcessTokenPrivilege - AdjustTokenPrivileges Failed , Error Code Is {0} , Error Message Is {1} ! \n"));

		CloseHandle(hToken);

		return FALSE;
	}
	return true;
}


//=====================================================================================//
//Name: bool OutputErrorMessage()                                                      //
//                                                                                     //
//Descripion: ��ӡ����ǰ��������� GetLastError �������Ĵ��󣬱�ʾʧ��  		               //
//=====================================================================================//
bool CSSDTProcessDlg::OutputErrorMessage(LPTSTR lpszMsg)
{
	LPVOID lpszBufMsg;
	LPVOID lpszBufErrorMsg;
	DWORD dwError = GetLastError();

	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM, NULL, dwError, 
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR)&lpszBufErrorMsg, 0, NULL);

	lpszBufMsg = (LPVOID)LocalAlloc(LMEM_ZEROINIT, sizeof(TCHAR) * 256);
	StringCchPrintf((LPTSTR)lpszBufMsg, LocalSize(lpszBufMsg), lpszMsg, dwError, lpszBufErrorMsg);

	OutputDebugString((LPTSTR)lpszBufMsg);

	LocalFree(lpszBufMsg);

	return FALSE;
}


//=====================================================================================//
//Name: bool OutputSuccessMessage()                                                    //
//                                                                                     //
//Descripion: ʵ�ִ�ӡһ����Ϣ��������ʾ�����ɹ�	    							     	   //
//=====================================================================================//
bool CSSDTProcessDlg::OutputSuccessMessage(LPTSTR lpszMsg)
{
	OutputDebugString(lpszMsg);

	return TRUE;
}


//�˳�Ӧ�ó���
void CSSDTProcessDlg::OnBnClickedCancel()
{
	if(this->m_hDevice)
	{
		CloseHandle(this->m_hDevice);
	}

	CDialogEx::OnCancel();
}


//���ؽ��̻���ȡ���Խ��̵�����
void CSSDTProcessDlg::OnBnClickedBtnHideorunhide()
{
	int nIndex;
	DWORD dwPID;
	CString cStrText;
	CString cStrState;
	
	DWORD dwOutput;
	BOOL bRet;
	CHAR inBuffer[10];
	CHAR outBuffer[10];
	memset(inBuffer, 0, 10);
	memset(outBuffer, 0, 10);

	dwPID = this->GetDlgItemInt(IDC_STATIC_SELECTED_PID);
	this->GetDlgItemText(ID_BTN_HIDEORUNHIDE, cStrText);

	ultoa(dwPID, inBuffer, 10);

	nIndex = QueryItemIndexByPID(dwPID);
	cStrState = this->m_ListCtrlProcess.GetItemText(nIndex, 4);

	if(cStrText.CompareNoCase(_TEXT("Hide")) == 0)
	{
		//���� dwPID
		bRet = DeviceIoControl(this->m_hDevice, IO_INSERT_HIDE_PROCESS, inBuffer, 10, &outBuffer, 10, &dwOutput, NULL);
		if(bRet)
		{
			this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("UnHide"));
			if(cStrState.CompareNoCase(_TEXT("Protect")) == 0)
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("HideAndProtect"));
			}
			else
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("Hide"));
			}
			MessageBox(_TEXT(" Hide Process Sucess !  "), _TEXT("Information"), MB_OK | MB_ICONINFORMATION);
		}
		else
		{
			MessageBox(_TEXT(" Hide Process Failed !  "), _TEXT("Warning"), MB_OK | MB_ICONERROR);
		}
	}
	else
	{
		//��� dwPID ����
		bRet = DeviceIoControl(this->m_hDevice, IO_REMOVE_HIDE_PROCESS, inBuffer, 10, &outBuffer, 10, &dwOutput, NULL);
		if(bRet)
		{
			this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("Hide"));
			if(cStrState.CompareNoCase(_TEXT("Protect")) == 0 || cStrState.CompareNoCase(_TEXT("HideAndProtect"))== 0)
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("Protect"));
			}
			else
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("General"));
			}
			MessageBox(_TEXT(" UnHide Process Sucess !  "), _TEXT("Information"), MB_OK | MB_ICONINFORMATION);
		}
		else
		{
			MessageBox(_TEXT(" UnHide Process Failed !  "), _TEXT("Warning"), MB_OK | MB_ICONERROR);
		}
	}
}


//�������̻���ȡ���Խ��̵ı�������
void CSSDTProcessDlg::OnBnClickedBtnProtectorunprotect()
{
	int nIndex;
	DWORD dwPID;
	CString cStrText;
	CString cStrState;

	DWORD dwOutput;
	BOOL bRet;
	CHAR inBuffer[10];
	CHAR outBuffer[10];
	memset(inBuffer, 0, 10);
	memset(outBuffer, 0, 10);

	dwPID = this->GetDlgItemInt(IDC_STATIC_SELECTED_PID);
	this->GetDlgItemText(ID_BTN_PROTECTORUNPROTECT, cStrText);

	ultoa(dwPID, inBuffer, 10);

	nIndex = QueryItemIndexByPID(dwPID);
	cStrState = this->m_ListCtrlProcess.GetItemText(nIndex, 4);

	if(cStrText.CompareNoCase(_TEXT("Protect")) == 0)
	{
		//���� dwPID ����
		bRet = DeviceIoControl(this->m_hDevice, IO_INSERT_PROTECT_PROCESS, inBuffer, 10, &outBuffer, 10, &dwOutput, NULL);
		if(bRet)
		{
			this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("UnProtect"));
			if(cStrState.CompareNoCase(_TEXT("Hide"))== 0)
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("HideAndProtect"));
			}
			else
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("Protect"));
			}
			MessageBox(_TEXT(" Protect Process Sucess !  "), _TEXT("Information"), MB_OK | MB_ICONINFORMATION);
		}
		else
		{
			MessageBox(_TEXT(" Protect Process Failed !  "), _TEXT("Warning"), MB_OK | MB_ICONERROR);
		}
	}
	else
	{
		//��� dwPID ����
		bRet = DeviceIoControl(this->m_hDevice, IO_REMOVE_PROTECT_PROCESS, inBuffer, 10, &outBuffer, 10, &dwOutput, NULL);
		if(bRet)
		{
			this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("Protect"));
			if(cStrState.CompareNoCase(_TEXT("Hide")) == 0 || cStrState.CompareNoCase(_TEXT("HideAndProtect")) == 0)
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("Hide"));
			}
			else
			{
				this->m_ListCtrlProcess.SetItemText(nIndex, 4, _TEXT("General"));
			}
			MessageBox(_TEXT(" UnProtect Process Sucess !  "), _TEXT("Information"), MB_OK | MB_ICONINFORMATION);
		}
		else
		{
			MessageBox(_TEXT(" UnProtect Process Failed !  "), _TEXT("Warning"), MB_OK | MB_ICONERROR);
		}
	}
}


//���� ListCtrl ��ѡ������ı�ʱ����Ϣ
void CSSDTProcessDlg::OnItemChangedListProcess(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

	UINT uOldState = pNMLV->uOldState; 
	UINT uNewState = pNMLV->uNewState; 
	if(pNMLV->iItem != -1) 
	{ 
		//Item Selected
		if(!(uOldState & LVIS_SELECTED) && (uNewState & LVIS_SELECTED)) 
		{ 
			int nItem;
			CString cStrPID;
			CString cStrState;

			nItem = this->m_currSeletedIndex = pNMLV->iItem;

			cStrPID = this->m_ListCtrlProcess.GetItemText(nItem, 1);
			cStrState = this->m_ListCtrlProcess.GetItemText(nItem, 4);

			this->SetDlgItemText(IDC_STATIC_SELECTED_PID, cStrPID);
			this->GetDlgItem(ID_BTN_HIDEORUNHIDE)->EnableWindow(TRUE);
			this->GetDlgItem(ID_BTN_PROTECTORUNPROTECT)->EnableWindow(TRUE);

			if(cStrState.CompareNoCase(_TEXT("General")) == 0)
			{
				this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("Hide"));
				this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("Protect"));
			}
			else if(cStrState.CompareNoCase(_TEXT("Hide")) == 0)
			{
				this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("UnHide"));
				this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("Protect"));
			}
			else if(cStrState.CompareNoCase(_TEXT("Protect")) == 0)
			{
				this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("Hide"));
				this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("UnProtect"));
			}
			else if(cStrState.CompareNoCase(_TEXT("HideAndProtect")) == 0)
			{
				this->SetDlgItemText(ID_BTN_HIDEORUNHIDE, _TEXT("UnHide"));
				this->SetDlgItemText(ID_BTN_PROTECTORUNPROTECT, _TEXT("UnProtect"));
			}
			else if(cStrState.CompareNoCase(_TEXT("Unknown")) == 0)
			{
				this->GetDlgItem(ID_BTN_HIDEORUNHIDE)->EnableWindow(FALSE);
				this->GetDlgItem(ID_BTN_PROTECTORUNPROTECT)->EnableWindow(FALSE);
			}
		} 

		//Item DeSelected
		if((uOldState & LVIS_SELECTED) && !(uNewState & LVIS_SELECTED)) 
		{ 
			//TRACE("item   deselected %d", pNMLV->iItem);
		} 
	}

	*pResult = 0;
}


//��ʾ���ڶԻ���
void CSSDTProcessDlg::OnBnClickedBtnAbout()
{
	AboutDialog cAboutDialog;
	cAboutDialog.DoModal();
}


//=====================================================================================//
//Name: bool InstallSvc()                                                              //
//                                                                                     //
//Descripion: ��װ����																   //
//            lpszSvcName Ϊ�������ƣ�												   //
//            lpszDisplay Ϊ��ʾ�ڷ�����ƹ������е����ƣ�								   //
//            lpszSvcBinaryPath Ϊ����ӳ���ļ�����·����								   //
//            dwSvcType Ϊ��������													   //
//            dwStartType Ϊ������������			 							     	   //
//=====================================================================================//
bool CSSDTProcessDlg::InstallSvc(LPTSTR lpszSvcName, LPTSTR lpszDisplayName, LPTSTR lpszSvcBinaryPath, DWORD dwSvcType, DWORD dwStartType)
{
	SC_HANDLE hSCM = NULL;
	SC_HANDLE hSvc = NULL;

	AdjustProcessTokenPrivilege();

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if(NULL == hSCM)
	{
		OutputErrorMessage(TEXT("InstallSvc - OpenSCManager Failed , Error Code Is %d , Error Message Is %s !"));

		return FALSE;
	}

	for(int i = 0; i < 3 && (NULL == hSvc); i++)
	{
		//SERVICE_WIN32_OWN_PROCESS  | SERVICE_INTERACTIVE_PROCESS
		hSvc = CreateService(hSCM, lpszSvcName, lpszDisplayName, SERVICE_ALL_ACCESS, 
			dwSvcType, dwStartType, SERVICE_ERROR_NORMAL, 
			lpszSvcBinaryPath, NULL, NULL, NULL, NULL, NULL);
		if(NULL != hSvc)
		{
			if(NULL != hSvc)
			{
				CloseServiceHandle(hSvc);
			}
			CloseServiceHandle(hSCM);
			return TRUE;
		}
	}

	OutputErrorMessage(TEXT("InstallSvc - CreateService Failed , Error Code Is %d , Error Message Is %s !"));

	CloseServiceHandle(hSCM);

	return FALSE;
}


//=====================================================================================//
//Name: bool UnInstallSvc()							                                   //
//                                                                                     //
//Descripion: ʵ��ж�ط���					    							     	   //
//=====================================================================================//
bool CSSDTProcessDlg::UnInstallSvc(LPTSTR lpszSvcName)
{
	SC_HANDLE hSCM = NULL;
	SC_HANDLE hSvc = NULL;
	bool rtResult = FALSE;

	AdjustProcessTokenPrivilege();

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if(NULL == hSCM)
	{
		OutputErrorMessage(TEXT("UnInstallSvc - OpenSCManager Failed , Error Code Is %d , Error Message Is %s !"));

		return FALSE;
	}

	hSvc = OpenService(hSCM, lpszSvcName, SERVICE_ALL_ACCESS);
	if(NULL == hSvc)
	{
		OutputErrorMessage(TEXT("UnInstallSvc - OpenService Failed , Error Code Is %d , Error Message Is %s !"));

		CloseServiceHandle(hSCM);

		return FALSE;
	}

	rtResult = DeleteService(hSvc);

	CloseServiceHandle(hSvc);
	CloseServiceHandle(hSCM);

	return rtResult;
}


//=====================================================================================//
//Name: bool StartSvc()								                                   //
//                                                                                     //
//Descripion: ʵ����������					    							     	   //
//=====================================================================================//
bool CSSDTProcessDlg::StartSvc(LPTSTR lpszSvcName)
{
	SC_HANDLE hSCM = NULL;
	SC_HANDLE hSvc = NULL;
	bool rtResult = FALSE;

	AdjustProcessTokenPrivilege();

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if(NULL == hSCM)
	{
		OutputErrorMessage(TEXT("StartSvc - OpenSCManager Failed , Error Code Is %d , Error Message Is %s !"));

		return FALSE;
	}

	hSvc = OpenService(hSCM, lpszSvcName, SERVICE_ALL_ACCESS);
	if(NULL == hSvc)
	{
		OutputErrorMessage(TEXT("StartSvc - OpenService Failed , Error Code Is %d , Error Message Is %s !"));

		CloseServiceHandle(hSCM);

		return FALSE;
	}

	rtResult = StartService(hSvc, NULL, NULL);

	CloseServiceHandle(hSvc);
	CloseServiceHandle(hSCM);

	if(FALSE == rtResult)
	{
		if(ERROR_SERVICE_ALREADY_RUNNING == GetLastError())
		{
			return TRUE;
		}
		else
		{
			OutputErrorMessage(TEXT("StartSvc - StartService Failed , Error Code Is %d , Error Message Is %s !"));

			return FALSE;
		}
	}
	else
	{
		return TRUE;
	}
}


//=====================================================================================//
//Name: bool StopSvc()								                                   //
//                                                                                     //
//Descripion: ʵ��ֹͣ����					    							     	   //
//=====================================================================================//
bool CSSDTProcessDlg::StopSvc(LPTSTR lpszSvcName)
{
	SC_HANDLE hSCM = NULL;
	SC_HANDLE hSvc = NULL;
	bool rtResult = FALSE;

	SERVICE_STATUS svcStatus;

	AdjustProcessTokenPrivilege();

	hSCM = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if(NULL == hSCM)
	{
		OutputErrorMessage(TEXT("StopSvc - OpenSCManager Failed , Error Code Is %d , Error Message Is %s !"));

		return FALSE;
	}

	hSvc = OpenService(hSCM, lpszSvcName, SERVICE_ALL_ACCESS);
	if(NULL == hSvc)
	{
		OutputErrorMessage(TEXT("StopSvc - OpenService Failed , Error Code Is %d , Error Message Is %s !"));

		CloseServiceHandle(hSCM);

		return FALSE;
	}

	rtResult = ControlService(hSvc, SERVICE_CONTROL_STOP, &svcStatus);
	if(rtResult == FALSE)
	{
		OutputErrorMessage(TEXT("StopSvc - ControlService Failed , Error Code Is %d , Error Message Is %s !"));
	}
	CloseServiceHandle(hSvc);
	CloseServiceHandle(hSCM);

	return rtResult;
}