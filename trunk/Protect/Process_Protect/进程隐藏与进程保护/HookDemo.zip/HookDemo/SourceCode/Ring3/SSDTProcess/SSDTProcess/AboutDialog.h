#pragma once


// AboutDialog �Ի���

class AboutDialog : public CDialogEx
{
	DECLARE_DYNAMIC(AboutDialog)

public:
	AboutDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~AboutDialog();

// �Ի�������
	enum { IDD = IDD_ABOUT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
private:
	void SetResourceImageToCtrl(LPCTSTR lpszImgType, int nCtrlCode, int nImgResourceID);
public:
	afx_msg void OnBnClickedLogBtn();
	afx_msg void OnBnClickedButton2();
};
