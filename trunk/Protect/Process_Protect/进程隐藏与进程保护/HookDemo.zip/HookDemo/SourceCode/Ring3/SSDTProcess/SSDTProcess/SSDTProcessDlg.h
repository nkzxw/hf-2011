
// SSDTProcessDlg.h : ͷ�ļ�
//

#pragma once

#include <WinIoCtl.h>
#include <Psapi.h>
#include <vector>
#include <map>
#include <string>
#include <strsafe.h>
#include <winsvc.h>
#include "afxwin.h"
#include "afxcmn.h"

using std::vector;
using std::map;
using std::wstring;

#pragma comment(lib, "Psapi.lib")

#define MAX_PROCESS_COUNT				1024
#define SSDT_PROCESS_TIMER_ID			10012
#define SSDT_PROCESS_TIMER_INTERVAL		1500


#define SSDT01_SYS_FILE_PATH			L"\\SSDT01.sys"

#define SSDT01_SERVICE_NAME				L"SSDT01"

#define SSDT01_DEVICE_NAME				L"\\\\.\\SSDT01ByZachary"

#define	SSDT01_DEVICE_TYPE				FILE_DEVICE_UNKNOWN

//��������Ӧ�ó������������ͨ�ŵĺ꣬����ʹ�õ��ǻ�������д��ʽ
#define	IO_INSERT_HIDE_PROCESS			(ULONG) CTL_CODE(SSDT01_DEVICE_TYPE, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	IO_REMOVE_HIDE_PROCESS			(ULONG) CTL_CODE(SSDT01_DEVICE_TYPE, 0x802, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	IO_INSERT_PROTECT_PROCESS		(ULONG) CTL_CODE(SSDT01_DEVICE_TYPE, 0x803, METHOD_BUFFERED, FILE_ANY_ACCESS)
#define	IO_REMOVE_PROTECT_PROCESS		(ULONG) CTL_CODE(SSDT01_DEVICE_TYPE, 0x804, METHOD_BUFFERED, FILE_ANY_ACCESS)

//�Զ���Ľ���״̬ö������
typedef enum _PROCESS_STATE
{
	ProcessStateGeneral,
	ProcessStateHide,
	ProcessStateProtect,
	ProcessStateHideAndProtect,
	ProcessStateUnknown

}PROCESS_STATE;


//�Զ���Ľ��� ID �ͽ���״̬�󶨺�����ݽṹ
typedef struct _PROCESS_BIND 
{
	DWORD dwPID;
	PROCESS_STATE state;

}PROCESS_BIND, * PPROCESS_BIND;


class CSSDTProcessDlg : public CDialogEx
{
public:
	CSSDTProcessDlg(CWnd* pParent = NULL);

	~CSSDTProcessDlg()
	{
		//�����������йر� SSDT �豸���
		if(this->m_hDevice)
		{
			CloseHandle(this->m_hDevice);
		}

		//��������������ʱ��ֹͣ������ж�ط���
		StopSvc(SSDT01_SERVICE_NAME);
		UnInstallSvc(SSDT01_SERVICE_NAME);
	}

	enum { IDD = IDD_SSDTPROCESS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);

private:
	//���������洢���̺ͽ���״̬�󶨺����Ϣ����������
	vector<PROCESS_BIND> m_vctAllProcess;
	//���� Map STL
	map<wstring, wstring> mapDvc2Path;
	DWORD m_currSeletedIndex;
	HANDLE m_hDevice;

private:
	void InitListCtrl();
	void FillPIDVector();
	BOOL ValidateProcess(DWORD dwPID);
	void ClearVector();
	BOOL IsExistInVectorAllProcess(DWORD dwPID);
	void BindVectorProcessToListCtrl();
	int IsExistInListCtrl(DWORD dwPID);
	void InsertProcessToListCtrl(PROCESS_BIND procBind, int nIndex);
	void BubbleSort(PDWORD dwPIDArray, int len);
	void VectorProcessBubbleSort();
	int GetInsertIndexInListCtrl(DWORD dwPID);
	int QueryItemIndexByPID(DWORD dwPID);
	wstring GetSysFilePath();

private:
	void VolumeName2DeviceName(PWCHAR DeviceName, PWCHAR VolumeName);
	bool LoadVolumeAndDeviceName2Map();
	void DeviceName2PathName(WCHAR* szPathName, const WCHAR* szDeviceName);
	BOOL AdjustProcessTokenPrivilege();
	bool OutputErrorMessage(LPTSTR lpszMsg);
	bool OutputSuccessMessage(LPTSTR lpszMsg);

	bool InstallSvc(LPTSTR lpszSvcName, LPTSTR lpszDisplayName, LPTSTR lpszSvcBinaryPath, DWORD dwSvcType, DWORD dwStartType);
	bool UnInstallSvc(LPTSTR lpszSvcName);
	bool StartSvc(LPTSTR lpszSvcName);
	bool StopSvc(LPTSTR lpszSvcName);
	bool InstallServiceIsOK();

protected:
	HICON m_hIcon;

	//���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);

private:
	CListCtrl m_ListCtrlProcess;
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedBtnHideorunhide();
	afx_msg void OnBnClickedBtnProtectorunprotect();
	afx_msg void OnItemChangedListProcess(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnAbout();
};
